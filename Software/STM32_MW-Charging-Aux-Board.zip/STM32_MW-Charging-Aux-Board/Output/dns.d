..\..\output\dns.o: ..\..\User\lwip\src\core\dns.c
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/opt.h
..\..\output\dns.o: ..\..\User\lwip\arch\lwipopts.h
..\..\output\dns.o: C:\Program Files\Keil_v5\ARM\ARMCC\Bin\..\include\stdlib.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/debug.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/arch.h
..\..\output\dns.o: ..\..\User\lwip\arch/cc.h
..\..\output\dns.o: C:\Program Files\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
..\..\output\dns.o: ..\..\Libraries\CMSIS\Device\ST\STM32F4xx\Include\stm32f4xx.h
..\..\output\dns.o: ..\..\Libraries\CMSIS\Include\core_cm4.h
..\..\output\dns.o: C:\Program Files\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
..\..\output\dns.o: ..\..\Libraries\CMSIS\Include\core_cmInstr.h
..\..\output\dns.o: ..\..\Libraries\CMSIS\Include\core_cmFunc.h
..\..\output\dns.o: ..\..\Libraries\CMSIS\Include\core_cmSimd.h
..\..\output\dns.o: ..\..\Libraries\CMSIS\Device\ST\STM32F4xx\Include\system_stm32f4xx.h
..\..\output\dns.o: ..\..\User\stm32f4xx_conf.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_adc.h
..\..\output\dns.o: ..\..\Libraries\CMSIS\Device\ST\STM32F4xx\Include\stm32f4xx.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_crc.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_dbgmcu.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_dma.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_exti.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_flash.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_gpio.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_i2c.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_iwdg.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_pwr.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_rcc.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_rtc.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_sdio.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_spi.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_syscfg.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_tim.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_usart.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_wwdg.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\misc.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_cryp.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_hash.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_rng.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_can.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_dac.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_dcmi.h
..\..\output\dns.o: ..\..\Libraries\STM32F4xx_StdPeriph_Driver\inc\stm32f4xx_fsmc.h
..\..\output\dns.o: ..\..\User\BSP\Inc\stm32f429_eth_conf.h
..\..\output\dns.o: C:\Program Files\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
..\..\output\dns.o: C:\Program Files\Keil_v5\ARM\ARMCC\Bin\..\include\inttypes.h
..\..\output\dns.o: C:\Program Files\Keil_v5\ARM\ARMCC\Bin\..\include\limits.h
..\..\output\dns.o: C:\Program Files\Keil_v5\ARM\ARMCC\Bin\..\include\ctype.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/opt.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/def.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/udp.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/pbuf.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/err.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/netif.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/ip_addr.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/ip4_addr.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/ip6_addr.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/stats.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/mem.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/memp.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/priv/memp_std.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/priv/memp_std.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/priv/memp_priv.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/priv/mem_priv.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/stats.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/ip.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/ip4.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/prot/ip4.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/ip6.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/prot/ip.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/prot/udp.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/dns.h
..\..\output\dns.o: ..\..\User\lwip\src\include\lwip/prot/dns.h
..\..\output\dns.o: C:\Program Files\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
