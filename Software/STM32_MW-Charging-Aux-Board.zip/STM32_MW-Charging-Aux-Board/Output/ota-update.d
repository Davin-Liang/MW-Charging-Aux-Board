..\..\output\ota-update.o: ..\..\User\OTA\Src\ota-update.c
..\..\output\ota-update.o: ..\..\User\OTA\Inc\ota-update.h
